package com.example.animalfacts.domain.model

class FactFilter {
    var animalType: String = "cat"
    var amount = 5
}